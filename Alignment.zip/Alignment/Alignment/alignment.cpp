#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <Fourier.h>
#include <cmdLineParser.h>
#include <Image.h>
#include <fstream>
#include <sstream>
#include <ctime>
#include <vector>
#include <algorithm>

//typedef int (*compfn)( const void* , const void* ) ;

struct Alignments
{
	std::string read_num ;
	int read_len ;
	std::string read_seq ;
	int read_beg ;
	double match_score ;
} ;

struct compare
{
	inline bool operator() ( const Alignments& read1 , const Alignments& read2 )
	{
		return ( read1.read_beg <= read2.read_beg ) ;
	}
} ;

//int compare ( struct Alignments* begin1 , struct Alignments* begin2 ) {
//	printf ("%d. comparing...\t" , c );
//	c++ ;
//	if ( begin1->read_beg < begin2->read_beg )
//		return -1 ;
//	else if ( begin1->read_beg > begin2->read_beg )
//		return 1 ;
//	else 
//		return 0 ;
//}


template<class Real>
int WriteImage(CircularArray<Real>& red,CircularArray<Real>& green,CircularArray<Real>& blue,char* fileName){
	if(red.resolution()!=green.resolution() || red.resolution()!=blue.resolution()){
		fprintf(stderr,"Resolutions differ: red[%d] green[%d] blue[%d]\n",red.resolution(),green.resolution(),blue.resolution());
		return 0;
	}
	Image32 img;
	int r=red.resolution();
	img.setSize(r,25);

	for(int i=0;i<r;i++){
		for(int j=0;j<25;j++){
			Pixel32 p;
			Real r,g,b;
			r=red(i);
			g=green(i);
			b=blue(i);
			if(r<0){r=0;}
			if(r>1){r=1;}
			if(g<0){g=0;}
			if(g>1){g=1;}
			if(b<0){b=0;}
			if(b>1){b=1;}
			p.r=(unsigned char)(r*255.0);
			p.g=(unsigned char)(g*255.0);
			p.b=(unsigned char)(b*255.0);
			img(i,j)=p;
		}
	}

	char* ext=GetFileExtension(fileName);
	if(!strcasecmp(ext,"bmp")){BMPWriteImage(img,fileName);}
	else if(!strcasecmp(ext,"jpg") || !strcasecmp(ext,"jpeg")){JPEGWriteImage(img,fileName);}
	else{
		fprintf(stderr,"Unsupported image extension: %s\n",ext);
		delete[] ext;
		return 0;
	}
	delete[] ext;
	return 1;
}
//
//void ForwardFFT(const CircularArray<>& values,Complex<>* coeffs){
//	CircularArray <> even , odd;
//	int n = values.resolution();
//	if (n == 1) {
//		coeffs[0].r = values(0);
//		coeffs[0].i = 0;
//		return;
//	}
//
//	// divide
//	even.resize(n/2);
//	odd.resize(n/2);
//	for ( int x = 0 ; x < n/2 ; x++ ) {
//		even(x) = values(2*x);
//		odd(x)	= values(2*x + 1);
//	}
//
//	// conquer
//	ForwardFFT(even, coeffs);
//	ForwardFFT(odd, (coeffs+n/2));
//
//	// combine
//	Complex<>* temp = new Complex<>[n];
//	for ( int k = 0 ; k < n ; k++ ) {
//		Complex<> t = Complex<>(cos(-2*PI*k/(double)n), sin(-2*PI*k/(double)n));
//		t = coeffs[(k%(n/2))+(n/2)]*t;
//		temp[k].r		= coeffs[k%(n/2)].r + t.r;
//		temp[k].i		= coeffs[k%(n/2)].i + t.i;
//	}
//
//	for ( int k = 0 ; k < n ; k++ ) {
//		coeffs[k] = temp[k];
//	}
//}
//
//void ComplexForwardFFT(const CircularArray<Complex <double> >& values,Complex<>* coeffs){
//	CircularArray < Complex < double> > even , odd;
//	int n = values.resolution();
//	if (n == 1) {
//		coeffs[0].r = values(0).r;
//		coeffs[0].i = values(0).i;
//		return;
//	}
//
//	// divide
//	even.resize(n/2);
//	odd.resize(n/2);
//	for ( int x = 0 ; x < n/2 ; x++ ) {
//		even(x).r = values(2*x).r;
//		even(x).i = values(2*x).i;
//		odd(x).r	= values(2*x + 1).r;
//		odd(x).i	= values(2*x + 1).i;
//	}
//
//	// conquer
//	ComplexForwardFFT(even, coeffs);
//	ComplexForwardFFT(odd, (coeffs+n/2));
//
//	// combine
//	Complex<>* temp = new Complex<>[n];
//	for ( int k = 0 ; k < n ; k++ ) {
//		Complex<> t = Complex<>(cos(-2*PI*k/(double)n), sin(-2*PI*k/(double)n));
//		t = coeffs[(k%(n/2))+(n/2)]*t;
//		temp[k].r		= coeffs[k%(n/2)].r + t.r;
//		temp[k].i		= coeffs[k%(n/2)].i + t.i;
//	}
//
//	for ( int k = 0 ; k < n ; k++ ) {
//		coeffs[k].r = temp[k].r;
//		coeffs[k].i = temp[k].i;
//	}
//}
//
//void InverseFFT(const Complex<>* coeffs,CircularArray<>& values){
//	int n = values.resolution();
//	Complex<> conj, nconj;
//
//	CircularArray< Complex <double> > val;
//	val.resize(n);
//	for ( int x = 0 ; x < n ; x++ ) {
//		conj = coeffs[x].conjugate();
//		val(x).r = conj.r;
//		val(x).i = conj.i;
//	}
//
//	Complex<> *ncoeffs;
//	ncoeffs = new Complex<>[n];
//	ComplexForwardFFT(val, ncoeffs);
//
//	for ( int x = 0 ; x < n ; x++ ) {
//		values(x) = ncoeffs[x].conjugate().r;
//	}
//}


int main( int argc , char* argv[] )
{
	// Read the parameters in from the command line
	cmdLineString Ref , Reads , Out ;
	char* paramNames[] = { "ref" , "read" , "out" } ;
	cmdLineReadable* params[] = { &Ref , &Reads , &Out } ;
	cmdLineParse( argc-1 , &argv[1] , paramNames , sizeof(paramNames)/sizeof(char*) , params ) ;
	if( !Ref.set || !Reads.set || !Out.set )
	{
		fprintf( stderr , "Usage %s:\n" , argv[0] ) ;
		fprintf( stderr , "\t--ref  <input reference_file.fa>\n" );
		fprintf( stderr , "\t--read <input read_file.fq>\n");
		fprintf( stderr , "\t--out  <output sequence alignment/map file>\n");
		return EXIT_FAILURE;
	}

	std::ifstream ref_file , infile ;
	std::ofstream outfile ;

	ref_file.open(Ref.value) ;
	if (!ref_file) {
		printf( "Cannot open reference file!\n" ) ;
		return EXIT_FAILURE ;
	}

	int b = 0 ;
	char refline[500];
	std::string refstr = "" ,
		ref_name = "" ;
	while ( ref_file.good() )
	{
		ref_file.getline( refline , 500 ) ;
		if (b == 0) {
			ref_name = refline ;
			int spacePos = ref_name.find_first_of(" ") ;
			if (spacePos == -1)
				ref_name = "*" ;
			else
				ref_name = ref_name.substr( 1 , spacePos ) ;
			b++ ;
			continue ;
		}
		refstr += refline ;
	}
	//printf( "%s\n\n" , refstr ) ;
	const char* ref = refstr.c_str() ;

	infile.open(Reads.value) ;
	if (!infile) {
		printf( "Cannot open file containing reads!\n" ) ;
		return EXIT_FAILURE ;
	}
	
	std::vector<Alignments> dataBase ;

	//char* ref = "GGGCGGCGACCTCGCGGGTTTTCGCTATTTATGAAAATTTTCCGGTTTAAGGCGTTTCCGTTCTTCTTCGTCATAACTTAATGTTTTTATTTAAAATACCCTCTGAAAAGAAAGGAAACGACAGGTGCTGAAAGCGAGGCTTTTTGGCCTCTGTCGTTTCCTTTCTCTGTTTTTGTCCGTGGAATGAACAATGGAAGTCAACAAAAAGCAGCTGGCTGACATTTTCGGTGCGAGTATCCGTACCATTCAGAACTGGCAGGAACAGGGAATGCCCGTTCTGCGAGGCGGTGGCAAGGGTAATGAGGTGCTTTATGACTCTGCCGCCGTCATAAAATGGTATGCCGAAAGGGATGCTGAAATTGAGAACGAAAAGCTGCGCCGGGAGGTTGAAGAACTGCGGCAGGCCAGCGAGGCAGATCTCCAGCCAGGAACTATTGAGTACGAACGCCATCGACTTACGCGTGCGCAGGCCGACGCACAGGAACTGAAGAATGCCAGAGACTCCGCTGAAGTGGTGGAAACCGCATTCTGTACTTTCGTGCTGTCGCGGATCGCAGGTGAAATTGCCAGTATTCTCGACGGGCTCCCCCTGTCGGTGCAGCGGCGTTTTCCGGAACTGGAAAACCGACATGTTGATTTCCTGAAACGGGATATCATCAAAGCCATGAACAAAGCAGCCGCGCTGGATGAACTGATACCGGGGTTGCTGAGTGAATATATCGAACAGTCAGGTTAACAGGCTGCGGCATTTTGTCCGCGCCGGGCTTCGCTCACTGTTCAGGCCGGAGCCACAGACCGCCGTTGAATGGGCGGATGCTAATTACTATCTCCCGAAAGAATCCGCATACCAGGAAGGGCGCTGGGAAACACTGCCCTTTCAGCGGGCCATCATGAATGCGATGGGCAGCGACTACATCCGTGAGGTGAATGTGGTGAAGTCTGCCCGTGTCGGTTATTCCAAAATGCTGCTGGGTGTTTATGCCTACTTTATAGAGCATAAGCAGCGCAACACCCTTATCTGGTT" ;
	int res , pRes ;
	float l2;
	CircularArray<> cIn , temp , cPattern , mask , cOut ;
	Complex<>* coeffs;
	
	// Read in the array
	//cIn.read(In.value);
	//res=cIn.resolution();

	// Read in the reference
	cIn.Read(ref) ;
	res = cIn.resolution() ;
	printf( "\nAligning to reference of length %d... " , res ) ;

	CircularArray<> dotprod , winnorm , inputsq ;
	FourierKey1D<> iKey, pKey, dKey, sKey, wKey, mKey ;
	FourierTransform<> xForm ;

	inputsq.resize(res) ;
	for ( int i = 0 ; i < res ; i++ )
		inputsq(i) = cIn(i)*cIn(i) ;

	xForm.ForwardFourier(cIn , iKey) ;
	int n = iKey.size() ;
	xForm.ForwardFourier(inputsq , sKey) ;

	int a = 0 ;
	int rds = 0 ;
	int aligned = 0 ;
	double total_T = 0 ;

	std::string samfile = Out.value ;
	samfile = samfile + ".SAM" ;
	outfile.open( samfile ) ;
	//outfile.open( "outc.csv" ) ;
	//outfile << "Read #, Read Length, Read, Match Start Position, Match End Positin, Score\n" ;
	outfile << "@HD VN:1.0  SO:unsorted\n@SQ SN:" << ref_name << "\tLN:" << res << "\n@PG ID:FFTLab\tPN:FFTLab\tVN:1.0\n" ;

	char line[500];
	while ( infile.good() )
	{
		infile.getline( line , 500 ) ;
		std::string r = line ;

		//outfile << str.c_str() << "\t" ; 
		r = r.substr(2, r.length() ) ;
		outfile << "r" << r << "\t" ;
		rds++ ;
		
		infile.getline( line , 500 ) ;
		std::string str = line ;
		//std::istringstream str ( In.value ) ;
		//std::string word ;
		//while( std::getline(str , word , '.' ) ) 
		//	printf("%s\n" , word.c_str() ) ;
			
		//const char* read = "ATGTTTTTATTTAAAATACCCTCTGAAAAGAAAGGAAACGACAGGTGCTGAAAGCGAGGCTTTT" ;
		const char* rd = str.c_str() ; 
		/*if (a==1)
			read = "ATGTTTTTATTTAAAATACCCTCTGAAAAGAAAGGAAACGACAGGTGCTGAAAGCGAGGCTTTT" ;
		else
			read = "GCGGCAGGCCAGCGAGGCAGATCTCCAGCCAGGAACTATTGAGTACGAACGCCATCGACTTACGCGTGCGCAGGCCGACGCACAGGAACTGAAGAATGCCAGAGAC" ;*/
			
		// Read in the reads
		temp.Read(rd) ;
		pRes = temp.resolution() ;

		// Check that the read is smaller than the image
		if (res < pRes) {
			fprintf( stderr , "\nRead must be smaller than reference: %d < %d\n\n" , pRes , res ) ;
			a++ ;
			continue ;
		}

		// Copy the read to a re-centered, zero-padded array, and set the mask
		cPattern.resize(res) ;
		mask.resize(res) ;
		for ( int i = 0 ; i < pRes ; i++ ) {
			cPattern(i-pRes/2) = temp(i) ;
			mask(i-pRes/2) = 1 ;
		}

		// Do alignment here
		// ...
		double T = (double)time(NULL) ;

		xForm.ForwardFourier(cPattern , pKey) ;

		dKey.resize(res) ;

		// dkey = res , loop = n
		for ( int i = 0 ; i < n ; i++ )
			dKey(i) = iKey(i)*pKey(i).conjugate() ;

		xForm.InverseFourier(dKey, dotprod) ;

		xForm.ForwardFourier(mask , mKey ) ;
	
		wKey.resize(res) ;
		for ( int i = 0 ; i < n ; i++ )
			wKey(i) = sKey(i)*mKey(i).conjugate() ;

		xForm.InverseFourier(wKey , winnorm) ;

		double sqnorm = cPattern.squareNorm() ;

		cOut.resize(res) ;
		for ( int i = 0 ; i < res ; i++ )
			cOut(i) = sqnorm + winnorm(i) - 2*dotprod(i) ; 

// The average value of (x-y)*(x-y) with x,y in [0,1] is 1/6.
// Multiplying this by the square norm of hte mask gives us the
// expected square L2-difference of two random signals on the mask.
// We divide the moving square L2-difference by this value to get a 
// functio that hsould roughly be in the range [0,1]
//float scale = (float)(mask.squareNorm()/6.f) ;

//// Normalize by the expected error
//for ( int i = 0 ; i < res ; i++ )
//	cOut(i)/=scale ;

// Find max
		float max = FLT_MIN ; 
		for ( int i = 0 ; i < res ; i++ )
			if ( cOut(i) > max )
				max = cOut(i) ;

		// Scale and invert the image so that brighter spots correspond to better matches, and range lies in [0,1]
		float best_match = FLT_MIN ;
		int i_best_match = -1 ;
		for ( int i = 0 ; i < res ; i++ ) {
			cOut(i) = cOut(i)/max ;
			cOut(i) = 1.f - cOut(i) ;
			if ( cOut(i) > best_match ) {
				best_match	 = cOut(i) ;
				i_best_match = i ;
			}
		}
		total_T += ((double)time(NULL) - T) ;

		//printf("\nBest Match:\n") ;
		//for ( int i = i_best_match - pRes/2 ; i < i_best_match + ceil( (double)pRes/2.f ) ; i++ )
		//	//printf( "%c" , ref[i] ) ;
		//	outfile << ref[i] ;
		//outfile << "\n" ;

		//printf( "\nScore = Ref(%d) = %f\n" , i_best_match , best_match ) ; 
		//outfile << i_best_match << ":" << best_match << "\n\n" ;
		
		bool b_aligned = false ;
		if (0.918 < best_match && best_match < 1.082) {
			//WriteImage( cOut, cOut, cOut , "cOut.bmp" );

			b_aligned = true ;
			Alignments newRead ;
			newRead.read_num = r ;
			newRead.read_len = pRes ;
			newRead.read_seq = str ;
			newRead.read_beg = i_best_match - pRes/2 + 1 ;
			newRead.match_score = best_match ;
			dataBase.push_back(newRead) ;

			//outfile << r << "," << pRes << "," << rd << "," ;
			//outfile << i_best_match - pRes/2 + 1 << "," << i_best_match + ceil( (double)pRes/2.f ) + 1 << "," << best_match << "\n" ;
			aligned++ ;

			// Write SAM output
			outfile << "0\t" << ref_name << "" << i_best_match - pRes/2 + 1 << "\t42\t" << pRes << "M\t*\t0\t0\t" << rd << "\t" ;
		}
		else
			outfile << "4\t*\t0\t0\t*\t*\t0\t0\t" << rd << "\t" ;


		//}
		//str.clear() ;
		infile.getline( line , 500 ) ;
		/*str = line ;
		str.clear() ;*/
		infile.getline( line , 500 ) ;
		outfile << line << "\t" ;
		if (b_aligned)
			outfile << "AS:i:" << best_match << "\tYT:Z:UU\n" ;
		else
			outfile << "ZS:i:" << best_match << "\tYT:Z:UU\n" ;

		//str = line ;
		/*else {
			a++ ;
			continue ;
		}
	
		a++ ;*/
		
	}
	outfile.close() ;
	infile.close() ;
	
	printf( "Done\n" ) ;
	printf( "\n%d reads; of these:\n  %d (%f%%) were unpaired; of these:\n" , rds , rds , rds/rds*100.f ) ;
	printf( "    %d (%f%%) aligned 0 times\n    %d (%f%%) aligned exactly 1 time\n    %d (%f%%) aligned >1 times\n" 
		, rds - aligned , (rds - aligned)*100.f/(float)rds , aligned , aligned*100.f/(float)rds , 0 , 0.00 ) ;
	printf( "%f%% overall alignment rate\n" , aligned*100.f/(float)rds ) ;
	printf( "Time taken to perform alignment: %fs\n" , total_T ) ; 

	printf( "\nSorting alignments... " ) ;
	std::sort( dataBase.begin() , dataBase.end() , compare() ) ;
	printf( "Done\n" ) ;

	std::string glfile = Out.value ;
	glfile = glfile + ".GL" ;
	outfile.open( glfile ) ;
	for ( int i = 0 ; i < dataBase.size() ; i++ )
	{
		outfile << dataBase[i].read_num << "\t" << dataBase[i].read_len << "\t" << dataBase[i].read_seq << "\t" << dataBase[i].read_beg << "\t" << dataBase[i].match_score ;
		int j = i+1 ;
		if ( j < dataBase.size() )
		{
			do {
				outfile << "\t" << dataBase[j].read_num ;
				j++ ;
			} while ( dataBase[i].read_beg+dataBase[i].read_len > dataBase[j].read_beg && j < dataBase.size() ) ;
			outfile << "\n" ;
		}
	}
	//int i = dataBase.size()-1 ;
	//glfile << dataBase[i].read_num << "\t" << dataBase[i].read_len << "\t" << dataBase[i].read_seq << "\t" << dataBase[i].read_beg << "\t" << dataBase[i].match_score ;

//	std::qsort( /*(void*)*/ &dataBase, dataBase.size() , sizeof( struct Alignments) , (compfn)compare ) ;

	/*
	// -----------------------------------------------------------------------------------------------
	// Allocate space for the Fourier coefficients
	coeffs=new Complex<>[res];
	
	// Run the forward and inverse Fourier transforms
	ForwardFFT(cIn,coeffs);
	cOut.resize(res);
	InverseFFT(coeffs,cOut);

	// Correct for the scaling term
	for(int i=0;i<res;i++){cOut(i)/=res;}



	// Test that the Fourier coefficients satisfy the conjugacy relations (difference should be zero)
	l2=0;
	for(int i=0;i<res;i++){l2+=(coeffs[i]-coeffs[(res-i)%res].conjugate()).squareNorm();}
	printf("Conjugate Test: %f\n",l2);



	// Compare the input and output (the difference should be zero)
	printf("Forward-Inverse Test: %f\n",CircularArray<>::SquareDifference(cIn,cOut));


	
	// Now compare the values of the Fourier coefficients (difference should be zero)
	FourierKey1D<> key;
	//FourierTransform<> xForm;

	xForm.ForwardFourier(cIn,key); //what is up with this?
	l2=0;
	float m=float(1.0/(2.0*PI))*key.resolution();
	for(int i=0;i<key.size();i++){l2+=(key(i)*m-coeffs[i]).squareNorm();}
	printf("Coefficient test: %f\n",l2);
	*/

	return EXIT_SUCCESS;
}